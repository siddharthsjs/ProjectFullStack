﻿namespace BankCustomerAPI.Models
{
    public class RolePermission
    {
        public int RoleId { get; set; }
        public Role Role { get; set; }

        public int PermissionId { get; set; }
        public Permission Permission { get; set; }  // <-- THIS WAS MISSING
    }
}
